# GalgameMap AstrBot プラグイン

GalgameMap の情報を AstrBot のチャットから検索し、同好会への参加申請をグループや DM に同期するプラグインです。beta0.5 から、超管は GalOnly イベントのブースと Staff 申請の照会・同期も行えます。

- 現在のバージョン: **beta0.5**
- ダウンロード: https://www.map.vnfest.top/downloads/astrbot_plugin_galgamemap_beta0.5.zip
- 詳細ガイド: https://www.map.vnfest.top/wiki/guide/#/astrbot/install-and-sync

詳しい使い方は USER_GUIDE.ja.md を参照してください。
